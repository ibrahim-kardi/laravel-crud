<?php

use Illuminate\Support\Facades\Route;



Route::get('/', function () {
    return view('welcome');
});

Route::get('/about', 'AboutController@AllContact')->name('all.contact');
Route::get('/insert-data', 'AboutController@InsertData');
Route::post('/data-added', 'AboutController@DataAdded');

Route::get('/delete-data/{id}', 'AboutController@Delete');
Route::get('/edit-data/{id}', 'AboutController@Edit');
Route::get('/view-data/{id}', 'AboutController@View');

Route::post('/update-data/{id}', 'AboutController@Update');

Route::get('/contact', function () {
    return view('pages.contact');
});

Route::get('laracast','AboutController@Index') ->name('laracast');

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-BmbxuPwQa2lc/FVzBcNJ7UAyJxM6wuqIj61tLrc4wSX0szH/Ev+nYRRuWlolflfl" crossorigin="anonymous">



<h1>Contact page</h1>

<a href="{{ URL::to('/') }}" class="btn btn-primary">Home</a><br>

<a href="{{ URL::to('/insert-data') }}" class="btn btn-primary">Add New</a><br>

<table class="table table-border">
    <tr>
        <th>Id</th>
        <th>Name</th>
        <th>Email</th>
        <th>Phone</th>
        <th>Action</th>
    </tr>
    @foreach($showdata as $data)


    <tr>
        <th>{{$data->id}}</th>
        <th>{{$data->name}}</th>
        <th>{{$data->email}}</th>
        <th>{{$data->phone}}</th>
        <th><button>
                <a href="{{URL::to('view-data/'.$data->id)}}" class="btn btn-info">View</a>
                <a href="{{URL::to('edit-data/'.$data->id)}}" class="btn btn-success">Update</a>
                <a href="{{URL::to('delete-data/'.$data->id)}}" class="btn btn-danger">Delete</a>
            </button>
        </th>
    </tr>

    @endforeach
</table>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/js/bootstrap.bundle.min.js" integrity="sha384-b5kHyXgcpbZJO/tY9Ul7kGkf1S0CWuKcCD38l8YkeH8z8QjE0GmW1gYU5S9FOnJ0" crossorigin="anonymous"></script>


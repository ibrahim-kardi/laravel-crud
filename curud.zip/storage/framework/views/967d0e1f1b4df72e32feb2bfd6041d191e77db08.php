Name: <?php echo e($vew->name); ?> <br>

Email: <?php echo e($vew->email); ?> <br>

Phone: <?php echo e($vew->phone); ?> <br>

Description: <?php echo e($vew->description); ?>

<?php /**PATH D:\xamp\htdocs\inventory\resources\views/pages/view.blade.php ENDPATH**/ ?>
<?php

namespace App\Admin;

use Illuminate\Database\Eloquent\Model;

class about extends Model
{
    //
}

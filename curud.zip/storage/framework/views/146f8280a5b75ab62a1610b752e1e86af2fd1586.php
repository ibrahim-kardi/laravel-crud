<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-BmbxuPwQa2lc/FVzBcNJ7UAyJxM6wuqIj61tLrc4wSX0szH/Ev+nYRRuWlolflfl" crossorigin="anonymous">



<h1>Contact page</h1>

<a href="<?php echo e(URL::to('/')); ?>" class="btn btn-primary">Home</a><br>

<a href="<?php echo e(URL::to('/insert-data')); ?>" class="btn btn-primary">Add New</a><br>

<table class="table table-border">
    <tr>
        <th>Id</th>
        <th>Name</th>
        <th>Email</th>
        <th>Phone</th>
        <th>Action</th>
    </tr>
    <?php $__currentLoopData = $showdata; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


    <tr>
        <th><?php echo e($data->id); ?></th>
        <th><?php echo e($data->name); ?></th>
        <th><?php echo e($data->email); ?></th>
        <th><?php echo e($data->phone); ?></th>
        <th><button>
                <a href="<?php echo e(URL::to('view-data/'.$data->id)); ?>" class="btn btn-info">View</a>
                <a href="<?php echo e(URL::to('edit-data/'.$data->id)); ?>" class="btn btn-success">Update</a>
                <a href="<?php echo e(URL::to('delete-data/'.$data->id)); ?>" class="btn btn-danger">Delete</a>
            </button>
        </th>
    </tr>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/js/bootstrap.bundle.min.js" integrity="sha384-b5kHyXgcpbZJO/tY9Ul7kGkf1S0CWuKcCD38l8YkeH8z8QjE0GmW1gYU5S9FOnJ0" crossorigin="anonymous"></script>

<?php /**PATH D:\xamp\htdocs\inventory\resources\views/pages/contact.blade.php ENDPATH**/ ?>
<form method="POST" action="<?php echo e(url('data-added')); ?>">
    <?php echo csrf_field(); ?>
    <input type="text" name="name" placeholder="Name">
    <input type="email" name="email" placeholder="Email">
    <input type="text" name="phone" placeholder="001856888">
    <input type="text" name="desc" placeholder="Description">
    <input type="submit" name="submit" value="Submit">
</form>
<?php /**PATH D:\xamp\htdocs\inventory\resources\views/pages/insert.blade.php ENDPATH**/ ?>
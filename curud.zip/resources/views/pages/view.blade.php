Name: {{$vew->name}} <br>

Email: {{$vew->email}} <br>

Phone: {{$vew->phone}} <br>

Description: {{$vew->description}}

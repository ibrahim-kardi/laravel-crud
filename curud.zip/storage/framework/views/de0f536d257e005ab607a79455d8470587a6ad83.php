<form method="POST" action="<?php echo e(url('update-data/'.$edt->id)); ?>">
    <?php echo csrf_field(); ?>
    <input type="text" name="name" value="<?php echo e($edt->name); ?>">
    <input type="email" name="email" value="<?php echo e($edt->email); ?>">
    <input type="text" name="phone" value="<?php echo e($edt->phone); ?>">
    <input type="text" name="desc" value="<?php echo e($edt->description); ?>">
    <input type="submit" name="submit" value="Submit">
</form>
<?php /**PATH D:\xamp\htdocs\inventory\resources\views/pages/editcontact.blade.php ENDPATH**/ ?>
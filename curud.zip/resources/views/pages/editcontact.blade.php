<form method="POST" action="{{ url('update-data/'.$edt->id) }}">
    @csrf
    <input type="text" name="name" value="{{$edt->name}}">
    <input type="email" name="email" value="{{$edt->email}}">
    <input type="text" name="phone" value="{{$edt->phone}}">
    <input type="text" name="desc" value="{{$edt->description}}">
    <input type="submit" name="submit" value="Submit">
</form>

<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class AboutController extends Controller
{
    public function Index(){
       return view('pages.laracast');
    }
    public function AllContact(){

        $contact = DB::select('select * from contacts');

        return view('pages.contact')->with('showdata',$contact);
    }

    public function InsertData(){

        return view('pages.insert');

    }
    public function DataAdded(Request $rquest){
        $data=array();

        $data['name']=$rquest->name;
        $data['email']=$rquest->email;
        $data['phone']=$rquest->phone;
        $data['description']=$rquest->desc;

        $ins = DB::table('contacts')->insert($data);
        //return redirect()->back();
        return redirect()->route('all.contact');
    }

    public function Delete($id){
        $dlt=DB::table('contacts')->where('id',$id)->delete();
        return redirect()->route('all.contact');
    }

    public function Edit($id){
        $edt=DB::table('contacts')->where('id',$id)->first();
        return view('pages.editcontact',compact('edt'));
    }

    public function Update( Request $request ,$id){

        $data= array();
        $data['name']=$request->name;
        $data['email']=$request->email;
        $data['phone']=$request->phone;
        $data['description']=$request->desc;

        $upd=DB::table('contacts')->where('id',$id)->update($data);
        return redirect()->route('all.contact');

    }

    public function View($id){
        $vew= DB::table('contacts')->where('id',$id)->first();

        return view('pages.view',compact('vew'));
    }
}

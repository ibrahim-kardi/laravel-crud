<form method="POST" action="{{ url('data-added') }}">
    @csrf
    <input type="text" name="name" placeholder="Name">
    <input type="email" name="email" placeholder="Email">
    <input type="text" name="phone" placeholder="001856888">
    <input type="text" name="desc" placeholder="Description">
    <input type="submit" name="submit" value="Submit">
</form>

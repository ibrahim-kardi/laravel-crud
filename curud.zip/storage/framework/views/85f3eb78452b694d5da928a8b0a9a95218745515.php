<h1>Laracst hi</h1>
<?php /**PATH D:\xamp\htdocs\inventory\resources\views/pages/laracast.blade.php ENDPATH**/ ?>